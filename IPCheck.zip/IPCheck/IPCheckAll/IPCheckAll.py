import sys
import urllib.request
import json
import time

def read_apikeys(filepath):
    keys = {}
    with open(filepath, "r") as f:
        for line in f:
            if "=" in line:
                k, v = line.strip().split("=", 1)
                keys[k.strip().lower()] = v.strip()
    return keys

def read_ip_list(filepath):
    with open(filepath, "r") as f:
        return [line.strip() for line in f if line.strip()]

def vt_query(ip, apikey):
    url = f"https://www.virustotal.com/api/v3/ip_addresses/{ip}"
    headers = {"x-apikey": apikey, "User-Agent": "Mozilla/5.0"}
    req = urllib.request.Request(url, headers=headers)
    try:
        with urllib.request.urlopen(req) as r:
            resp = json.loads(r.read())
        data = resp.get("data", {}).get("attributes", {})
        stats = data.get("last_analysis_stats", {})
        return {
            "Country": data.get("country", ""),
            "ASN": data.get("asn", ""),
            "AS Owner": data.get("as_owner", ""),
            "Network": data.get("network", ""),
            "Malicious": stats.get("malicious", ""),
            "Suspicious": stats.get("suspicious", ""),
            "Harmless": stats.get("harmless", ""),
            "Undetected": stats.get("undetected", ""),
            "Reputation": data.get("reputation", ""),
            "Tags": ", ".join(data.get("tags", [])),
            "Last Analysis": data.get("last_analysis_date", ""),
        }
    except Exception as e:
        return {"VT_Error": str(e)}

def ipinfo_query(ip, apikey):
    url = f"https://ipinfo.io/{ip}/json?token={apikey}"
    try:
        with urllib.request.urlopen(url) as r:
            data = json.loads(r.read())
        return {
            "City": data.get("city", ""),
            "Region": data.get("region", ""),
            "Country": data.get("country", ""),
            "Location": data.get("loc", ""),
            "Org": data.get("org", ""),
            "ASN": data.get("asn", {}).get("asn", "") if "asn" in data else "",
            "Provider": data.get("asn", {}).get("name", "") if "asn" in data else "",
            "Timezone": data.get("timezone", ""),
            "Hostname": data.get("hostname", ""),
        }
    except Exception as e:
        return {"IPINFO_Error": str(e)}

def shodan_query(ip, apikey):
    url = f"https://api.shodan.io/shodan/host/{ip}?key={apikey}"
    try:
        with urllib.request.urlopen(url) as r:
            data = json.loads(r.read())
        open_ports = sorted([str(p) for p in data.get("ports", [])])
        hostnames = ", ".join(data.get("hostnames", []))
        org = data.get("org", "")
        isp = data.get("isp", "")
        country = data.get("country_name", "")
        city = data.get("city", "")
        region = data.get("region_code", "")
        asn = data.get("asn", "")
        os = data.get("os", "")
        domains = ", ".join(data.get("domains", []))
        tags = ", ".join(data.get("tags", []))
        last_update = data.get("last_update", "")
        # Port details
        port_details = []
        for banner in data.get("data", []):
            port = banner.get("port")
            product = banner.get("product", "")
            transport = banner.get("transport", "")
            banner_short = banner.get("banner", "")
            banner_short = banner_short.replace("\n", " ")[:80]
            port_details.append(f"{port}: {product or transport} {banner_short}")
        return {
            "Open Ports": ", ".join(open_ports),
            "Port Details": " | ".join(port_details),
            "Hostnames": hostnames,
            "Organization": org,
            "ISP": isp,
            "Country": country,
            "City": city,
            "Region": region,
            "ASN": asn,
            "OS": os,
            "Domains": domains,
            "Tags": tags,
            "Last Update": last_update
        }
    except Exception as e:
        return {"SHODAN_Error": str(e)}

def main():
    if len(sys.argv) < 2:
        print("Usage: python IPCheckAll.py <iplist.txt>")
        sys.exit(1)
    apikeys = read_apikeys("apikeys.txt")
    vt_key = apikeys.get("virustotal")
    ipinfo_key = apikeys.get("ipinfo")
    shodan_key = apikeys.get("shodan")
    if not (vt_key and ipinfo_key and shodan_key):
        print("Missing one of the required API keys in apikeys.txt (virustotal, ipinfo, shodan)")
        sys.exit(1)
    ips = read_ip_list(sys.argv[1])
    if not ips:
        print("No IPs found in input file.")
        sys.exit(1)
    with open("ip_report.txt", "w", encoding="utf-8") as f:
        for ip in ips:
            f.write("="*60 + "\n")
            f.write(f"IP: {ip}\n")
            f.write("##################################################\n")
            f.write("VirusTotal:\n")
            vt = vt_query(ip, vt_key)
            for k, v in vt.items():
                f.write(f"  {k}: {v}\n")
            f.write("##################################################\n")
            f.write("ipinfo.io:\n")
            ipinfo = ipinfo_query(ip, ipinfo_key)
            for k, v in ipinfo.items():
                f.write(f"  {k}: {v}\n")
            f.write("##################################################\n")
            f.write("Shodan:\n")
            shodan = shodan_query(ip, shodan_key)
            for k, v in shodan.items():
                f.write(f"  {k}: {v}\n")
            f.write("\n")
            time.sleep(1)  # Avoid API rate limits
    print("Done! Output saved to ip_report.txt")

if __name__ == "__main__":
    main()
