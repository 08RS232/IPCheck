import sys
import os
import urllib.request
import json
import datetime

def read_apikey(filepath):
    keys = {}
    try:
        with open(filepath,"r") as f:
            for line in f:
                if "=" in line:
                    k, v = line.strip().split("=",1)
                    keys[k.strip()] = v.strip()
    except Exception as e:
        print(f"Error reading API keys: {e}")
    return keys.get("virustotal")

def read_ip_list(filepath):
    ips = []
    try:
        with open(filepath,"r") as f:
            for line in f:
                ip = line.strip()
                if ip:
                    ips.append(ip)
    except Exception as e:
        print(f"Error reading IP list: {e}")
    return ips

def format_unix_date(timestamp):
    try:
        dt = datetime.datetime.fromtimestamp(timestamp, datetime.UTC)
        return dt.strftime("%d-%m-%Y")
    except Exception:
        return str(timestamp)

def query_virustotal_ip(ip, api_key):
    url = f"https://www.virustotal.com/api/v3/ip_addresses/{ip}"
    headers = {
        "x-apikey": api_key,
        "User-Agent": "Mozilla/5.0"
    }
    req = urllib.request.Request(url, headers=headers)
    try:
        with urllib.request.urlopen(req) as response:
            resp = response.read()
            return json.loads(resp)
    except Exception as e:
        return {"error": str(e)}

def extract_ip_info(ip, info):
    try:
        if "error" in info:
            return {"error": info["error"]}

        attrs = info["data"]["attributes"]
        stats = attrs.get("last_analysis_stats", {})
        last_analysis_date = attrs.get("last_analysis_date")
        formatted_date = format_unix_date(last_analysis_date) if last_analysis_date else "Unknown"
        malicious_count = stats.get("malicious", 0)
        suspicious_count = stats.get("suspicious", 0)
        harmless_count = stats.get("harmless", 0)
        undetected_count = stats.get("undetected", 0)
        malicious = "Yes" if malicious_count and malicious_count > 0 else "No"
        reputation = attrs.get("reputation", "Unknown")
        country = attrs.get("country", "Unknown")
        network = attrs.get("network", "")
        as_owner = attrs.get("as_owner", "")
        categories = ", ".join(attrs.get("categories", []))
        tags = ", ".join(attrs.get("tags", []))
        rir = attrs.get("regional_internet_registry", "Unknown")
        asn = attrs.get("asn", "Unknown")
        whois = attrs.get("whois", "")
        whois_short = whois[:180].replace("\n"," ") + ("..." if len(whois) > 180 else "")
        permalink = f"https://www.virustotal.com/gui/ip-address/{ip}"

        return {
            "country": country,
            "network": network,
            "as_owner": as_owner,
            "malicious": malicious,
            "malicious_count": malicious_count,
            "suspicious_count": suspicious_count,
            "harmless_count": harmless_count,
            "undetected_count": undetected_count,
            "reputation": reputation,
            "categories": categories,
            "tags": tags,
            "rir": rir,
            "asn": asn,
            "whois_short": whois_short,
            "last_analysis": formatted_date,
            "permalink": permalink
        }
    except Exception as e:
        return {"error": f"Extract error: {e}"}

def print_ip_info(ip, ipinfo):
    print(f"\nIP: {ip}")
    if "error" in ipinfo:
        print(f"Error: {ipinfo['error']}")
    else:
        print(f" Country:          {ipinfo['country']}")
        print(f" Network:          {ipinfo['network']}")
        print(f" AS Owner:         {ipinfo['as_owner']}")
        print(f" ASN:              {ipinfo['asn']}")
        print(f" RIR:              {ipinfo['rir']}")
        print(f" Reputation:       {ipinfo['reputation']}")
        print(f" Categories:       {ipinfo['categories']}")
        print(f" Tags:             {ipinfo['tags']}")
        print(f" Last Analysis:    {ipinfo['last_analysis']}")
        print(f" Malicious:        {ipinfo['malicious']} (Detections: {ipinfo['malicious_count']})")
        print(f" Suspicious:       {ipinfo['suspicious_count']}")
        print(f" Harmless:         {ipinfo['harmless_count']}")
        print(f" Undetected:       {ipinfo['undetected_count']}")
        print(f" Whois:            {ipinfo['whois_short']}")
        print(f" Permalink:        {ipinfo['permalink']}")

def main():
    if len(sys.argv) < 2:
        print("Usage: python IPCheckv2.py <iplist.txt>")
        sys.exit(1)
    ipfile = sys.argv[1]
    apikey = read_apikey("apikeys.txt")
    if not apikey:
        print("VirusTotal API key missing in apikeys.txt")
        sys.exit(1)
    ips = read_ip_list(ipfile)
    if not ips:
        print("No IPs found in input file.")
        sys.exit(1)
    for ip in ips:
        info = query_virustotal_ip(ip, apikey)
        ipinfo = extract_ip_info(ip, info)
        print_ip_info(ip, ipinfo)

if __name__ == "__main__":
    main()
