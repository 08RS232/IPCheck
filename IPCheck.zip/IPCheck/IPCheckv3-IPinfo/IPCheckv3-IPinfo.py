import sys
import os
import urllib.request
import json

def read_apikey(filepath):
    keys = {}
    try:
        with open(filepath,"r") as f:
            for line in f:
                if "=" in line:
                    k, v = line.strip().split("=",1)
                    keys[k.strip()] = v.strip()
    except Exception as e:
        print(f"Error reading API keys: {e}")
    return keys.get("ipinfo")

def read_ip_list(filepath):
    ips = []
    try:
        with open(filepath,"r") as f:
            for line in f:
                ip = line.strip()
                if ip:
                    ips.append(ip)
    except Exception as e:
        print(f"Error reading IP list: {e}")
    return ips

def query_ipinfo(ip, api_key):
    url = f"https://ipinfo.io/{ip}/json?token={api_key}"
    headers = {
        "User-Agent": "Mozilla/5.0"
    }
    req = urllib.request.Request(url, headers=headers)
    try:
        with urllib.request.urlopen(req) as response:
            resp = response.read()
            return json.loads(resp)
    except Exception as e:
        return {"error": str(e)}

def print_ipinfo(ip, info):
    print(f"\nIP: {ip}")
    if "error" in info:
        print(f"  Error: {info['error']}")
    else:
        for k, v in info.items():
            print(f"  {k.capitalize()}: {v}")

def main():
    if len(sys.argv) < 2:
        print("Usage: python IPCheckv3-IPinfo.py <iplist.txt>")
        sys.exit(1)
    ipfile = sys.argv[1]
    apikey = read_apikey("apikeys.txt")
    if not apikey:
        print("ipinfo.io API key missing in apikeys.txt")
        sys.exit(1)
    ips = read_ip_list(ipfile)
    if not ips:
        print("No IPs found in input file.")
        sys.exit(1)
    for ip in ips:
        info = query_ipinfo(ip, apikey)
        print_ipinfo(ip, info)

if __name__ == "__main__":
    main()
