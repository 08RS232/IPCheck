import sys
import json
import urllib.request

def read_apikey(filepath):
    keys = {}
    try:
        with open(filepath, "r") as f:
            for line in f:
                if "=" in line:
                    k, v = line.strip().split("=", 1)
                    keys[k.strip()] = v.strip()
    except Exception as e:
        print(f"Error reading API keys: {e}")
    return keys.get("shodan")

def read_ip_list(filepath):
    ips = []
    try:
        with open(filepath, "r") as f:
            for line in f:
                ip = line.strip()
                if ip:
                    ips.append(ip)
    except Exception as e:
        print(f"Error reading IP list: {e}")
    return ips

def query_shodan(ip, api_key):
    url = f"https://api.shodan.io/shodan/host/{ip}?key={api_key}"
    headers = {
        "User-Agent": "Mozilla/5.0"
    }
    req = urllib.request.Request(url, headers=headers)
    try:
        with urllib.request.urlopen(req) as response:
            resp = response.read()
            return json.loads(resp)
    except Exception as e:
        return {"error": str(e)}

def print_shodan_ip_info(ip, info):
    print(f"\nIP: {ip}")
    if "error" in info:
        print(f"  Error: {info['error']}")
        return

    print(f"  Hostnames:   {', '.join(info.get('hostnames', [])) or 'N/A'}")
    print(f"  Organization:{info.get('org', 'N/A')}")
    print(f"  ISP:         {info.get('isp', 'N/A')}")
    print(f"  Country:     {info.get('country_name', 'N/A')}")
    print(f"  City:        {info.get('city', 'N/A')}")
    print(f"  Region:      {info.get('region_code', 'N/A')}")
    print(f"  ASN:         {info.get('asn', 'N/A')}")
    print(f"  Domains:     {', '.join(info.get('domains', [])) or 'N/A'}")
    print(f"  Tags:        {', '.join(info.get('tags', [])) or 'N/A'}")
    print(f"  OS:          {info.get('os', 'N/A')}")
    print(f"  Last Update: {info.get('last_update', 'N/A')}")
    print(f"  Open Ports:")
    ports = info.get('ports', [])
    if not ports:
        print("    None found.")
    else:
        # For more details, match port number with data banners
        banners = info.get('data', [])
        port_service = {}
        for banner in banners:
            port = banner.get('port')
            service = banner.get('product') or banner.get('transport') or ""
            desc = banner.get('banner', "")[:40].replace('\n', ' ')
            port_service[port] = f"{service} | {desc}"
        for port in sorted(ports):
            details = port_service.get(port, "")
            print(f"    {port} {details}")

def main():
    if len(sys.argv) < 2:
        print("Usage: python IPCheckv4-Shodan.py <iplist.txt>")
        sys.exit(1)
    ipfile = sys.argv[1]
    apikey = read_apikey("apikeys.txt")
    if not apikey:
        print("Shodan API key missing in apikeys.txt")
        sys.exit(1)
    ips = read_ip_list(ipfile)
    if not ips:
        print("No IPs found in input file.")
        sys.exit(1)
    for ip in ips:
        info = query_shodan(ip, apikey)
        print_shodan_ip_info(ip, info)

if __name__ == "__main__":
    main()
